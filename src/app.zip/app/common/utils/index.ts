// @ts-ignore
/**
 * app内专用工具集
 */
export function Test(){
  return "Test";
}