
import { ILocalesKeys } from "common.i18n";

/**
 * 日本語
 */
const JAPANESE: ILocalesKeys = {
  HELLO:"こんにちは"
};

export default JAPANESE;
