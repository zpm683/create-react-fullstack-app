
import { ILocalesKeys } from "common.i18n";

/**
 * 中国語
 */
const CHINESE: ILocalesKeys = {
  HELLO:"你好"
};

export default CHINESE;
