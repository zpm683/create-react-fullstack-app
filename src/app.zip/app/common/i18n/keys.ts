import { ILocalesKeys } from "common.i18n";

/**
 * TEXT
 */
export const TEXT: ILocalesKeys = {
  HELLO: "HELLO",
};
