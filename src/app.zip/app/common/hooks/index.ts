// export more or make you hooks
/**
 * hooks
 */

export { useLocalStorage, useSessionStorage } from "react-use";
