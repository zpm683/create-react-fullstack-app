/*
 * 需国际化的内容接口
 */
declare module "common.i18n" {
  export interface ILocalesKeys {
    /**
     * Hello
     */
    readonly HELLO: string;
  }
}
