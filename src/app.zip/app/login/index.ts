import Login from "./components/Login";
export default Login;
export {
  loginActions,
  loginReducer,
} from "./redux/loginSlice";
