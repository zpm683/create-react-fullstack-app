// import export
import MainMenu from "./components";
export default MainMenu;