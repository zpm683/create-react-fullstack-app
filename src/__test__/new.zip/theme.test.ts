/**
 * theme.ts unit test
 * @author FXS)zhang.puming
 */

import theme from "../app/theme";

describe("theme.ts unit test.", () => {
  it("theme", () => {
    expect(theme.palette.type).toBe("light");
  });
});
