/**
 * app/index.tsx unit test
 * @author FXS)zhang.puming
 */

import React from "react";
import { render } from "@testing-library/react";
import { App } from "../app";

describe("app/index.tsx unit test", () => {
  test("renders learn react link", () => {
    const { container } = render(<App />);
    expect(container).toBeDefined();
  });
});
