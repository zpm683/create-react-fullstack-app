/**
 * rootReducer.ts unit test
 * @author FXS)zhang.puming
 */
import { rootReducer } from "../app/rootReducer";

describe("rootReducer.ts unit test", () => {
  it("Case rootReducer", () => {
    expect(rootReducer).toBeDefined();
  });
});
