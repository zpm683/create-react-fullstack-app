/**
 * i18n unit test
 * @author FXS)zhang.puming
 */
import i18n from "../../../app/common/i18n/init";

describe("i18n unit test", () => {
  it("check init ", () => {
    expect(i18n).toBeDefined();
  });
});
